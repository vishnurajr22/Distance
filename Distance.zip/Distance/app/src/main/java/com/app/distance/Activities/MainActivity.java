package com.app.distance.Activities;


import android.graphics.Color;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;

import com.app.distance.AddStops.AddStopsFragment;
import com.app.distance.R;

public class MainActivity extends AppCompatActivity {
    Button placebutton;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        //starting activity with AddplaceFragment
        loadFragment(new AddStopsFragment());

    }

    private void initViews() {
        //nav bar
        BottomNavigationView bottomNavigationView=findViewById(R.id.navbar);
        bottomNavigationView.setOnNavigationItemSelectedListener(navListner);
    }

    private void loadFragment(Fragment fragment) {
        //selecting fragment
        FragmentManager fm = getSupportFragmentManager();

        fm.beginTransaction()
                .replace(R.id.framelayout, fragment)
                .commit();
    }

    private BottomNavigationView.OnNavigationItemSelectedListener navListner=
            new BottomNavigationView.OnNavigationItemSelectedListener() {
                @Override
                public boolean onNavigationItemSelected(@NonNull MenuItem menuItem) {

                    switch (menuItem.getItemId()){
                        case R.id.map:
                            loadFragment(new AddStopsFragment());
                            break;
                        case R.id.place:
                            loadFragment(new AddStopsFragment());
                            break;

                    }
                    return true;
                }
            };
}
