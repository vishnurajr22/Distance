package com.app.distance.CommonDataArea;

import android.app.AlertDialog;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.nfc.Tag;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.util.Log;

import com.app.distance.Activities.AddPlacesActivity;
import com.app.distance.Activities.MainActivity;

public class CommonFunctions {


public static AddPlacesActivity addPlacesActivity;
public static Context context=addPlacesActivity.getApplicationContext();
    public static Boolean internetcheck(){
        if (addPlacesActivity == null) return false;
        ConnectivityManager cm =
                (ConnectivityManager) addPlacesActivity.getApplicationContext().getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo netInfo = cm.getActiveNetworkInfo();
        if (netInfo != null && netInfo.isConnected()) {
            return true;
        } else
            return false;
    }
    public static void alertdialouge(String message){
        try {
            AlertDialog alertDialog = new AlertDialog.Builder(addPlacesActivity.getApplicationContext()).create();

            alertDialog.setTitle("Info");
            alertDialog.setMessage(message);
            alertDialog.setIcon(android.R.drawable.ic_dialog_alert);
            alertDialog.setButton("OK", new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    addPlacesActivity.finish();

                }
            });

            alertDialog.show();
        } catch (Exception e) {
            Log.d("TAG", "Show Dialog: " + e.getMessage());
        }

    }

    public String uuid(){

       String uuid= Settings.Secure.getString(addPlacesActivity.getContentResolver(), Settings.Secure.ANDROID_ID);
        return uuid;
    }


}
