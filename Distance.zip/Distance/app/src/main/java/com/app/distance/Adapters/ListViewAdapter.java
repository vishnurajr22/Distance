package com.app.distance.Adapters;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.app.distance.Model.PlaceModel;
import com.app.distance.R;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class ListViewAdapter extends ArrayAdapter<PlaceModel> {
    private Activity context;
    List<PlaceModel> artists;

    public ListViewAdapter(Activity context, List<PlaceModel> artists) {
        super(context,R.layout.waypoint_list_item,artists);
        this.context = context;
        this.artists = artists;
    }




    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View listViewItem = inflater.inflate(R.layout.waypoint_list_item, null, true);

        TextView textViewName = (TextView) listViewItem.findViewById(R.id.way_point_item);


        PlaceModel artist = artists.get(position);
        textViewName.setText(artist.getWaypoint());


        return listViewItem;
    }
}
